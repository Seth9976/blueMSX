#ifndef VERSION_H
#define VERSION_H

#define BLUE_MSX_VERSION_MAJOR 2
#define BLUE_MSX_VERSION_MINOR 5

#define BLUE_MSX_VERSION "2.5"

#endif
